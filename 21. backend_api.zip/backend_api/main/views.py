from django.shortcuts import render
from rest_framework import permissions
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView, ListAPIView
from rest_framework.viewsets import ModelViewSet

from .models import Customer, CustomerAddress, Order, OrderItems, Product, ProductCategory, ProductRating, Vendor
from .serializers import CategorySerializer, CustomerAddressSerializer, CustomerDetailSerializer, CustomerSerializer, OrderDetailSerializer, OrderSerializer, ProductDetailSerializer, ProductListSerializer, ProductRatingSerializer, VendorSerializer, VendorDetailSerializer

# Create your views here.
class VendorList(ListCreateAPIView):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    # permission_classes = [permissions.IsAuthenticated]

class VendorDetail(RetrieveUpdateDestroyAPIView):
    # queryset = Vendor.objects.all()
    serializer_class = VendorDetailSerializer
    # permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        return Vendor.objects.filter(pk=self.kwargs['pk'])

class ProductList(ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductListSerializer

class ProductDetail(RetrieveUpdateDestroyAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductDetailSerializer

class CustomerList(ListCreateAPIView):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class CustomerDetail(RetrieveUpdateDestroyAPIView):
    serializer_class = CustomerDetailSerializer
    def get_queryset(self):
        return Customer.objects.filter(pk=self.kwargs['pk'])

class OrderList(ListCreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

class OrderDetail(ListAPIView):
    # queryset = OrderItems.objects.all()
    serializer_class = OrderDetailSerializer

    def get_queryset(self):
        order = Order.objects.get(pk=self.kwargs['pk'])
        return OrderItems.objects.filter(order=order)

class CustomerAddressViewSet(ModelViewSet):
    queryset = CustomerAddress.objects.all()
    serializer_class = CustomerAddressSerializer

class ProductRatingViewSet(ModelViewSet):
    queryset = ProductRating.objects.all()
    serializer_class = ProductRatingSerializer

    # def get_queryset(self):
    #     customer = Customer.objects.get(pk=self.kwargs['pk'])
    #     return CustomerAddress.objects.filter(customer=customer)

# Category List API
class CategoryList(ListCreateAPIView):
    queryset = ProductCategory.objects.all()
    serializer_class = CategorySerializer
    # permission_classes = [permissions.IsAuthenticated]

class CategoryDetail(RetrieveUpdateDestroyAPIView):
    # queryset = Vendor.objects.all()
    serializer_class = CategorySerializer
    # permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        return ProductCategory.objects.filter(pk=self.kwargs['pk'])    
